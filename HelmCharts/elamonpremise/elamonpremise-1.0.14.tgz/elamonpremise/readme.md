# Lokale installation (Pfade müssen ggf. angepasst werden)
Namespace anlegen "elamonpremise" !!

