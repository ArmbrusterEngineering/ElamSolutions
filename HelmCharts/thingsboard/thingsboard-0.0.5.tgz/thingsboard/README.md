## ACHTUNG

wird nur intern verwendent (Aktuell Moonchild3!)

## Thingsboard Helm Chart

Installiert Thingsboard (3.6.4) auf MicroK8s inkl. HAProxy als TLS-Termination.

## Voraussetzungen

- `helm` lokal installiert
- `kubectl` konfiguriert auf den Zielserver (z.B. via OpenLens)
- Zugriff auf den Namespace `thingsboard`

---

## Erstinstallation

### 1. TLS-Zertifikat vorbereiten

Zertifikat und Key müssen als Base64 **mit Padding** vorliegen (Notepad++ → Plugins → MIME Tools → Base64 Encode).

### 2. Root CA vorbereiten (optional)

Wird benötigt wenn Thingsboard-Regelketten HTTPS-Endpunkte mit self-signed Zertifikat aufrufen.  
Die `.crt`-Datei muss als PEM vorliegen. Konvertierung aus DER-Format (z.B. `ELAM.crt`):

```powershell
$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("C:\Pfad\zur\ELAM.crt")
$b64 = [Convert]::ToBase64String($cert.RawData, [System.Base64FormattingOptions]::InsertLineBreaks)
"-----BEGIN CERTIFICATE-----`n$b64`n-----END CERTIFICATE-----"
```

### 3. values.yaml befüllen

```yaml
hostname: thingsboard.example.com
namespace: thingsboard

secret:
  tls:
    crt: <base64-kodiertes TLS-Zertifikat>
    key: <base64-kodierter TLS-Key>

rootCA:
  crt: |
    -----BEGIN CERTIFICATE-----
    MIID...
    -----END CERTIFICATE-----

postgresql:
  db: thingsboard
  auth:
    username: thingsboard
    password: <passwort>
```

> `rootCA.crt` weglassen oder leer lassen wenn kein eigenes Root-CA benötigt wird.

### 4. Dependencies laden

```powershell
helm dependency update C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard
```

### 5. Installieren

```powershell
helm install thingsboard C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard `
  --namespace thingsboard --create-namespace `
  -f C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard\values.yaml
```

---

## Update / Upgrade

### Aktueller Release-Name

```powershell
helm list --all-namespaces
```

Der Release-Name hat das Format `thingsboard-<timestamp>`, z.B. `thingsboard-1754645761`.

### Dry-Run (empfohlen vor jedem Upgrade)

```powershell
helm upgrade <release-name> C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard `
  --namespace thingsboard `
  --reuse-values `
  -f C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard\values.yaml `
  --dry-run=client
```

Gezielt auf relevante Änderungen filtern:

```powershell
helm upgrade <release-name> C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard `
  --namespace thingsboard --reuse-values `
  -f C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard\values.yaml `
  --dry-run=client 2>$null | Select-String -Pattern "SUCHBEGRIFF" -Context 2,2
```

### Upgrade durchführen

```powershell
helm upgrade <release-name> C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard `
  --namespace thingsboard `
  --reuse-values `
  -f C:\DevOps\ELAM\Cloud\deploy\charts\thingsboard\values.yaml
```

> `--reuse-values` übernimmt die im Cluster gespeicherten Werte.  
> `-f values.yaml` merged neue Werte aus der lokalen Datei darüber.  
> Beide Flags zusammen sind nötig damit neue Felder in values.yaml ankommen ohne alte Werte zu verlieren.

### Pod-Status überwachen

```powershell
kubectl get pods -n thingsboard -w
```

Normaler Ablauf nach Upgrade: `Init:0/1` → `PodInitializing` → `Running`

### Root-CA Import prüfen

```powershell
kubectl logs -n thingsboard -l app=tb-node -c import-root-ca
```

Erwartete Ausgabe:
```
Certificate was added to keystore
Root CA erfolgreich importiert.
```

---

## Funktionsweise Root CA

Ist `rootCA.crt` gesetzt, startet beim tb-node Pod ein Init-Container (`import-root-ca`) der:

1. Den JVM-Truststore (`cacerts`) aus dem Thingsboard-Image in ein temporäres Volume kopiert
2. Das Root-CA per `keytool` importiert
3. Den Haupt-Container mit `-Djavax.net.ssl.trustStore` auf diesen Truststore zeigen lässt

Damit vertrauen alle ausgehenden HTTPS-Verbindungen der Regelketten dem eigenen Root-CA.
